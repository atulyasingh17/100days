//Q2: Write a program to input two numbers and display their sum, difference, product, and quotient.

/*
Sample Test Cases:
Input 1:
10 2
Output 1:
Sum=12, Diff=8, Product=20, Quotient=5

Input 2:
7 3
Output 2:
Sum=10, Diff=4, Product=21, Quotient=2

*/

#include<stdio.h>
#include<math.h>
int main()
	{
		int a,b;
		printf("Enter 1st and 2nd number = ");
		 scanf("%d%d",&a,&b);
		printf("Sum = %d\n",a+b);
		printf("Difference = %d\n",a-b);
		printf("Product = %d\n",a*b);
		if(b==0)
		printf("Division Not Possible\n");
		else
		printf("Quotient = %d\n",a/b);
	}
