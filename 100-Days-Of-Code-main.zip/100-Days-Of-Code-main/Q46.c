#include <stdio.h>
int main()
{
   int r,c;
   for(r=1;r<6;r++)
    {
        {
            for(c=1;c<6;c++)
            printf("*");
        }
        printf("\n");
    }
}
