//Q55: Write a program to print all the prime numbers from 1 to n.

/*
Sample Test Cases:
Input 1:
10
Output 1:
2 3 5 7

Input 2:
20
Output 2:
2 3 5 7 11 13 17 19

*/

#include <stdio.h>
int main()
{
    int n,i,j,count,count1=0;
    printf("Enter N: ");
     scanf("%d",&n);
    
    for(i=1;i<=n;i++)
    {
        count=0;
        for(j=1;j<=i/2;j++)
        {
            if(i%j==0)
            count++;
        }
        
        if(count==1)
        {
           printf("%d ",i);
            count1++;
        }
    }
    printf("No. of prime numbers between 1 to %d are %d\n",n,count1);
}
