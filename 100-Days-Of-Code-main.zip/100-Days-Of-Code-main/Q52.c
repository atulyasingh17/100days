/*Q52: Write a program to print the following pattern:

*

*
*
*

*
*
*
*
*

*
*
*

*

*/
/*
Sample Test Cases:
Input 1:

Output 1:
Pattern with stars spaced irregularly as shown.

*/

#include <stdio.h>
int main()
{
    int i,n,brow,star;
    printf("enter a odd number: ");
    scanf("%d",&n);
    if(n%2!=0)
    {
    brow=(n+1)/2;
    for(i=1;i<=brow;i++)
    {
        for(star=1;star<=2*i-1;star++)
        {
            printf("*\n");
        }
        printf("\n");
    }
    for(i=1;i<=brow-1;i++) //brow =2
    {
        for(star=1;star<=(brow-i)*2-1;star++)
        {
            printf("*\n");
        }
        printf("\n");
    }
   

    }
    else
        printf("invalid no.");
}
